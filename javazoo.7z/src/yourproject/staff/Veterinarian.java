package org.yourcompany.yourproject.staff;

import org.yourcompany.yourproject.care.MedicalCheckable;

public class Veterinarian {
    public void checkAnimal(MedicalCheckable animal) {
        animal.performMedicalCheckup();
    }
}