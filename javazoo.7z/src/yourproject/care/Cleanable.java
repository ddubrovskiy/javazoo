package org.yourcompany.yourproject.care;

public interface Cleanable {
    void clean();
}