package org.yourcompany.yourproject.care;

public interface Exhibitable {
    void prepareForExhibition();
}