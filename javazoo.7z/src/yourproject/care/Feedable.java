package org.yourcompany.yourproject.care;

public interface Feedable {
    void feed();
}