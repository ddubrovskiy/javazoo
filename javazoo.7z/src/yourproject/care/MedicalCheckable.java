package org.yourcompany.yourproject.care;

public interface MedicalCheckable {
    void performMedicalCheckup();
}